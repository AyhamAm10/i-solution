export { Factory as Hero3D } from "./factory";

