export { Factory as ThemeToggle } from "./factory";

