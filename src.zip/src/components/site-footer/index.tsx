export { Factory as SiteFooter } from "./factory";

