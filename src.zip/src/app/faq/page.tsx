import { Factory } from "./factory";

export default function FAQPage() {
  return <Factory />;
}

