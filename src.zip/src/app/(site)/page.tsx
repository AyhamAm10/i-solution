import { Factory } from "./factory";

export default function HomePage() {
  return <Factory />;
}

