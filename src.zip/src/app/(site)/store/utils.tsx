type Params = {};

const store = (): Params => ({});

export { store as utilsStore };
export type { Params as utilsParams };

