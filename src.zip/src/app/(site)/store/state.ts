type Params = {};

const store = (): Params => ({});

export { store as stateStore };
export type { Params as stateParams };

