import { Factory } from "./factory";

export default function ProjectsPage() {
  return <Factory />;
}

