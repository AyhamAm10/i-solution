import { Factory } from "./factory";

export default function CoursesPage() {
  return <Factory />;
}

